# Foody GraphQL
Make my first try on GraphQL using NodeJS, Mongo and Apollo-Server, the only reason I choosed food is just because I love eating. hehe

### How To Setup Project
1. Clone this repository (I hope you guys doesn't push anything to master)
2. Run ```npm install``` and wait until you feel bored and drink some coffee except you are using M1 (Bismillah macbook gratis)
3. Go to terminal and run ```nodemon index.js``` if you don't have it, just install it with ```npm install -g nodemon```
4. Open ```http://localhost:4000/``` on your browser. In my case, the port is 4000 while you may have a different with me, just take a look at your terminal
5. Play around with it

### Little about GraphQL
GraphQL is the new standard of API and replace REST as a design paradigm and it's becoming the new standard for exposing the data and functionality of a web server.

### Documentation
1. [GraphQL](https://graphql.org/)
2. [Place I learn about GraphQL](https://www.howtographql.com/)
